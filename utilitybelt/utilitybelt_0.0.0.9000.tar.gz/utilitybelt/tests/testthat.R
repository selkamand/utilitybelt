library(testthat)
library(utilitybelt)

test_check("utilitybelt")
